<!DOCTYPE html>
<html>
<head>
	<title>HKU</title>
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>
	<h1>HKU Scapping Login page</h1>
	<form action="<?php echo e(url('/login')); ?>" method="post">
		<?php echo e(csrf_field()); ?>

		<input type="text" name="uid" value="limhoho">
		<input type="text" name="pin" value="6801953ooo">
		<button type="submit" name="">LOGIN</button>	
	</form>
	

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</body>
</html>