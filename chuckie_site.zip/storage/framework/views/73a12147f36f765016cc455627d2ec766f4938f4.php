<sapn class="navicon"><i class="fa fa-bars" aria-hidden="true"></i></sapn>
<div class="controls">
    <div class="search">
      <div class="input-group input-group-sm mb-3 seachItem">
        <div class="input-group-prepend">
          <span class="input-group-text search-icon" style="border: none;background-color: white;color: #999;" id="inputGroup-sizing-sm"><span class="fa fa-search"></span></span>
        </div>
        <input type="text" class="search-input" aria-label="Small" aria-describedby="inputGroup-sizing-sm" id="search" placeholder="Search by course code or course name">
      </div>
    </div>
    <div class="menus">
        <div class="profile">
            <div class="dropdown">
              <p class="dropdown-toggle" data-toggle="dropdown" id="profile_name">
              </p>
              <div class="dropdown-menu">
                <a class="dropdown-item" href="/logout">Logout</a>
              </div>
            </div>
        </div>
        <div>
            <img class="person-img" src="<?php echo e(asset('img/defualt-person.jpg')); ?>">    
        </div>
        
    </div>
    
</div>