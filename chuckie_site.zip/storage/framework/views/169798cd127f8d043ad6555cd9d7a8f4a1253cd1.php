<?php $__env->startSection('content'); ?>
<div class="loginContainer">
    <p class="title">GPA.AI</p>
    <p class="subtitle">Welcome back! Please login with Facebook</p>
    <div class="container" style="max-width: 400px;">
	    	<div class="form-group">
		    	<select class="form-control" name="universityID" id="university_id">
			    	<option value="0">The University of Hong Kong</option>
			    	<option value="1">The Chines University of Hong Kong</option>
			    	<option value="2">Hong Kong University of Science of Technology</option>
			    	<option value="3">The City University of Hong Kong</option>
			    </select>
			</div>
			<div class="form-group">
		    	<input type="text" class="form-control" name="portalID" id="portal_id" value="" placeholder="PortalID" required>
		    </div>
		    <div class="form-group">
		    	<input type="password"  class="form-control" name="password" id="password" value="" placeholder="Password" required>
		    </div>
		    <div class="form-group">
		    	<p class="error">Your credential is incorrect</p>
		    </div>

		    <div class="form-group">
		    	<button class="fbloginBtn" type="button">Join Us</button>
		    </div>

    </div>
    <div class="loader" style="display: none;"></div>
    <p class="terms">Term of use. Privacy Policy</p>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsinclude'); ?>
 <script src="<?php echo e(asset('js/main.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>