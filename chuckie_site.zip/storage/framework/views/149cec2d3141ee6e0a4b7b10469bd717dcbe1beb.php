<?php $__env->startSection('sidemenu'); ?>
<div class="menu-body">
    <div class="title">
        <p>GPA.AI<span class="fa fa-times" id="menu_close"></span></p>
    </div>
    <div class="menus">
       <div class="sidebar-menu-item inactive" id="menu_item_dashboard"><span class="fa fa-tachometer"></span>Notice Death</div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="header">
        <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>        
    </div>
    <div class="content-body">
        <table class="table">
            <thead>
                <th style="min-width: 130px !important;">Name<span class="arrows"><i class="fa fa-caret-up" aria-hidden="true" data-column="code-up"></i><i class="fa fa-caret-down" aria-hidden="true"  data-column="code-down"></i></span></th>
                <th>Town<span class="arrows"><i class="fa fa-caret-up" aria-hidden="true" data-column="course-up"></i><i class="fa fa-caret-down" aria-hidden="true"  data-column="course-down"></i></span></th>
                <th>Country<span class="arrows"><i class="fa fa-caret-up" aria-hidden="true" data-column="grade1-up"></i><i class="fa fa-caret-down" aria-hidden="true"  data-column="grade1-down"></i></span></th>
                <th>Published<span class="arrows"><i class="fa fa-caret-up" aria-hidden="true" data-column="grade2-up"></i><i class="fa fa-caret-down" aria-hidden="true"  data-column="grade2-down"></i></span></th>
                <th width="100px">Average<span class="arrows"><i class="fa fa-caret-up" aria-hidden="true" data-column="average-up"></i><i class="fa fa-caret-down" aria-hidden="true"  data-column="average-down"></i></span></th>
            </thead>
            <tbody id="table_body">
            </tbody>
        </table>
        <div class="loader"></div>
        
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jsinclude'); ?>

     <script src="<?php echo e(asset('js/dash.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>