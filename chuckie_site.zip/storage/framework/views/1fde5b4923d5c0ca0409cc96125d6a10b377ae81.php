<?php $__env->startSection('sidemenu'); ?>
<div class="menu-body">
    <div class="title">
        <p>GPA.AI<span class="fa fa-times" id="menu_close"></span></p>
    </div>
    <div class="menus">
        <div class="<?php echo e(($menu == 'dashboard') ? 'sidebar-menu-item active' : 'sidebar-menu-item inactive'); ?>" id="menu_item_dashboard"><span class="fa fa-tachometer"></span>Dashboard</div>
        <div class="<?php echo e(($menu == 'compare') ? 'sidebar-menu-item active' : 'sidebar-menu-item inactive'); ?>" id="menu_item_compare"><span class="fa fa-calculator"></span>Compare</div>    
    </div>
    <div class="setting">
        <span class="fa fa-cog"></span><p>Settings</p>
    </div>
    
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="header">
        <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div class="content-body">
       
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jsinclude'); ?>
     <script src="<?php echo e(asset('js/compare.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>