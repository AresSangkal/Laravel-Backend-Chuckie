<?php $__env->startSection('content'); ?>
<div class="loginContainer">
    <p class="title">GPA.AI</p>
    <p class="subtitle">Welcome back! Please login with Facebook</p>
    <button class="fbloginBtn" onclick="javascript:location.href='/auth/fb'"><img class="" src="<?php echo e(asset('img/fb_icon.png')); ?>">Login With Facebook</button>
    <p class="terms">Term of use. Privacy Policy</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>