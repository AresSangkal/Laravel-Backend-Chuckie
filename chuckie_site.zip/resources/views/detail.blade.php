<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Custom fonts for this theme -->
  <link href="{{ asset('vendor/fontawesome-free/css/all.min.css') }}" rel="stylesheet" type="text/css">
  <link href="{{ asset('//fonts.googleapis.com/css?family=Montserrat:400,700') }}" rel="stylesheet" type="text/css">
  <link href="{{ asset('//fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic') }}" rel="stylesheet" type="text/css">

  <!-- Theme CSS -->
  <link href="{{ asset('css/freelancer.css') }}" rel="stylesheet">
  <link href="{{ asset('//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css') }}" rel="stylesheet">
  <link href="{{ asset('//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css') }}" rel="stylesheet">
  <script src="{{ asset('//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js') }}"></script>
  <script src="{{ asset('//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js') }}"></script>

  <!-- Bootstrap core JavaScript -->
  <!-- <script src="{{ asset('vendor/jquery/jquery.min.js') }}"></script>
  <script src="{{ asset('vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script> -->

  <!-- Plugin JavaScript -->
  <!-- <script src="{{ asset('vendor/jquery-easing/jquery.easing.min.js') }}"></script> -->

  <!-- Contact Form JavaScript -->
  <script src="{{ asset('js/jqBootstrapValidation.js') }}"></script>
  <script src="{{ asset('js/contact_me.js') }}"></script>

  <!-- Custom scripts for this template -->
  <script src="{{ asset('js/freelancer.js') }}"></script>

</head>
<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg bg-secondary text-uppercase fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="{{ url('/') }}">NOTICES HOME</a>
      <button class="navbar-toggler navbar-toggler-right text-uppercase font-weight-bold bg-primary text-white rounded" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        Menu
        <i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item mx-0 mx-lg-1">
            <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#page-top" id="gonotices">Detail</a>
          </li>
          <li class="nav-item mx-0 mx-lg-1">
            <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#about" id="goabout">Map</a>
          </li>
          <li class="nav-item mx-0 mx-lg-1">
            <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#contact" id="gocontact">Contact</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Masthead -->
  <header class="masthead bg-primary text-white text-center">
    <div class="container d-flex align-items-center flex-column">

      <!-- Masthead Avatar Image -->
      <!-- <img class="masthead-avatar mb-5" src="{{ asset('img/avataaars.svg') }}" alt=""> -->

      <!-- Masthead Heading -->
      <h3 class="masthead-heading text-uppercase mb-0">{{$detail->firstname}}&nbsp;{{$detail->lastname}}</h3>
      


      <!-- Icon Divider -->
      <div class="divider-custom divider-light">
        <div class="divider-custom-line"></div>
        <div class="divider-custom-icon">
          <i class="fas fa-star"></i>
        </div>
        <div class="divider-custom-line"></div>
      </div>

      <!-- Masthead Subheading -->
      <p class="masthead-subheading font-weight-light mb-0 custom">{{$detail->towncounty}}</p>

    </div>
  </header>

  <!-- Portfolio Section -->
  <section class="page-section portfolio" id="notices">
    <div class="container">

      <!-- Portfolio Section Heading -->
      <h2 class="page-section-heading text-center text-uppercase text-secondary mb-0">Detail</h2>

      <!-- Icon Divider -->
      <div class="divider-custom">
        <div class="divider-custom-line"></div>
        <div class="divider-custom-icon">
          <i class="fas fa-star"></i>
        </div>
        <div class="divider-custom-line"></div>
      </div>

      <div class="row">
      <div class="description">{{$detail->description}}</div>
      @if($detail->deathdate)
        <div class="deathdate">Death Date:&nbsp;{{$detail->deathdate}}</div>
      @endif
      </div>
      <!-- /.row -->

    </div>
  </section>

  <!-- About Section -->
  <section class="page-section bg-primary text-white mb-0" id="about">
    <div class="container">

      <!-- About Section Heading -->
      <h2 class="page-section-heading text-center text-uppercase text-white">cemetary and church</h2>

      <!-- Icon Divider -->
      <div class="divider-custom divider-light">
        <div class="divider-custom-line"></div>
        <div class="divider-custom-icon">
          <i class="fas fa-star"></i>
        </div>
        <div class="divider-custom-line"></div>
      </div>
      

     
      <!-- About Section Content -->
      <div class="row">
        <div class="col-lg-4 ml-auto">
                @if($detail->chtype)
                <h2 class="namefix">{{$detail->chlocname}}</h2>
                <div class="map-custom" id="chmap"></div>
                @endif
        </div>
        <div class="col-lg-4 mr-auto">
                @if($detail->cetype)
                    <h2 class="namefix">{{$detail->celocname}}</h2>
                    <div class="map-custom" id="cemap"></div>
                @endif
        </div>
      </div>

      <!-- About Section Button -->
      <div class="text-center mt-4">

      </div>

    </div>
  </section>

  <!-- Contact Section -->
  <section class="page-section" id="contact">
    <div class="container">

      <!-- Contact Section Heading -->
      <h2 class="page-section-heading text-center text-uppercase text-secondary mb-0">Contact Me</h2>

      <!-- Icon Divider -->
      <div class="divider-custom">
        <div class="divider-custom-line"></div>
        <div class="divider-custom-icon">
          <i class="fas fa-star"></i>
        </div>
        <div class="divider-custom-line"></div>
      </div>

      <!-- Contact Section Form -->
      <div class="row">
        <div class="col-lg-8 mx-auto">
          <!-- To configure the contact form email address, go to mail/contact_me.php and update the email address in the PHP file on line 19. -->
          <form name="sentMessage" id="contactForm" novalidate="novalidate">
            <div class="control-group">
              <div class="form-group floating-label-form-group controls mb-0 pb-2">
                <label>Name</label>
                <input class="form-control" id="name" type="text" placeholder="Name" required="required" data-validation-required-message="Please enter your name.">
                <p class="help-block text-danger"></p>
              </div>
            </div>
            <div class="control-group">
              <div class="form-group floating-label-form-group controls mb-0 pb-2">
                <label>Email Address</label>
                <input class="form-control" id="email" type="email" placeholder="Email Address" required="required" data-validation-required-message="Please enter your email address.">
                <p class="help-block text-danger"></p>
              </div>
            </div>
            <div class="control-group">
              <div class="form-group floating-label-form-group controls mb-0 pb-2">
                <label>Phone Number</label>
                <input class="form-control" id="phone" type="tel" placeholder="Phone Number" required="required" data-validation-required-message="Please enter your phone number.">
                <p class="help-block text-danger"></p>
              </div>
            </div>
            <div class="control-group">
              <div class="form-group floating-label-form-group controls mb-0 pb-2">
                <label>Message</label>
                <textarea class="form-control" id="message" rows="5" placeholder="Message" required="required" data-validation-required-message="Please enter a message."></textarea>
                <p class="help-block text-danger"></p>
              </div>
            </div>
            <br>
            <div id="success"></div>
            <div class="form-group">
              <button type="submit" class="btn btn-primary btn-xl" id="sendMessageButton">Send</button>
            </div>
          </form>
        </div>
      </div>

    </div>
  </section>

  <!-- Footer -->
  <footer class="footer text-center">
    <div class="container">
      <div class="row">

        <!-- Footer Location -->
        <div class="col-lg-4 mb-5 mb-lg-0">
          <h4 class="text-uppercase mb-4">Location</h4>
          <p class="lead mb-0">2215 John Daniel Drive
            <br>Clark, MO 65243</p>
        </div>

        <!-- Footer Social Icons -->
        <div class="col-lg-4 mb-5 mb-lg-0">
          <h4 class="text-uppercase mb-4">Around the Web</h4>
          <a class="btn btn-outline-light btn-social mx-1" href="#">
            <i class="fab fa-fw fa-facebook-f"></i>
          </a>
          <a class="btn btn-outline-light btn-social mx-1" href="#">
            <i class="fab fa-fw fa-twitter"></i>
          </a>
          <a class="btn btn-outline-light btn-social mx-1" href="#">
            <i class="fab fa-fw fa-linkedin-in"></i>
          </a>
          <a class="btn btn-outline-light btn-social mx-1" href="#">
            <i class="fab fa-fw fa-dribbble"></i>
          </a>
        </div>

        <!-- Footer About Text -->
        <div class="col-lg-4">
          <h4 class="text-uppercase mb-4">About Death Notices</h4>
          <p class="lead mb-0">Death Notices is a free to use, FULL serviced Death Notices Site created by
            <a href="#">Start Chuckie</a>.</p>
        </div>

      </div>
    </div>
  </footer>

  <!-- Copyright Section -->
  <section class="copyright py-4 text-center text-white">
    <div class="container">
      <small>Copyright &copy; Your Website 2019</small>
    </div>
  </section>

  <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes) -->
  <div class="scroll-to-top d-lg-none position-fixed ">
    <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top">
      <i class="fa fa-chevron-up"></i>
    </a>
  </div>

  
  
<script type="text/javascript">
            $('.date').datepicker({  
                format: 'mm-dd-yyyy',
                autoclose: true
            });  
</script>
<script>
    $(document).ready(function(){  
        $("#gocontact").click(function(e) {
            e.preventDefault();
            $('html, body').animate({
            scrollTop: $($.attr(this, 'href')).offset().top
            }, 250);
        });
        $("#gonotices").click(function(e) {
            e.preventDefault();
            $('html, body').animate({
            scrollTop: $($.attr(this, 'href')).offset().top
            }, 250);
        });
        $("#goabout").click(function(e) {
            e.preventDefault();
            $('html, body').animate({
            scrollTop: $($.attr(this, 'href')).offset().top
            }, 250);
        });

    });
</script>
<script>

    @if($detail->cetype)
        var celat = <?php echo $detail->celat ?>;
        var celon = <?php echo $detail->celon ?>;
        var cezoom = <?php echo $detail->cezoom ?>;
    @endif
        
    @if($detail->chtype)
    var chlat = <?php echo $detail->chlat ?>;
    var chlon = <?php echo $detail->chlon ?>;
    var chzoom = <?php echo $detail->chzoom ?>;
    @endif

      var chmap;
      var cemap;
      function initMap() {
        chmap = new google.maps.Map(document.getElementById('chmap'), {
          center: {lat: chlat, lng: chlon},
          zoom: chzoom
        });
        cemap = new google.maps.Map(document.getElementById('cemap'), {
          center: {lat: celat, lng: celon},
          zoom: cezoom
        });
      }
      
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBMUq9n8z6pmRWIhiBtG0nQZIsz5F5lzcA&callback=initMap"
    async defer></script>
</body>
</html>