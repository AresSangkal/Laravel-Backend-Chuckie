@extends('layouts.login')

@section('content')
<div class="loginContainer">
    <p class="title">GPA.AI</p>
    <p class="subtitle">Welcome back! Please login with Facebook</p>
    <button class="fbloginBtn" onclick="javascript:location.href='/auth/fb'"><img class="" src="{{asset('img/fb_icon.png')}}">Login With Facebook</button>
    <p class="terms">Term of use. Privacy Policy</p>
</div>
@endsection
