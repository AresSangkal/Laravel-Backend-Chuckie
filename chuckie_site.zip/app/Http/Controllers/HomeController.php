<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Input;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {

    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $estates = [];
        $data['estates'] = $estates;
        return view("landing", $data);
    }

    public function search(Request $request)
    {
        $firstname = $request->input('firstname');
        $lastname = $request->input('lastname');
        $neename = $request->input('neename');
        $county = $request->input('county');
        $town = $request->input('town');
        if ($request->has('from') && $request->input('from') != '') {
            $date_from = Carbon::createFromFormat('m-d-Y', $request->input('from'));
        } else {
            $date_from = Carbon::createFromTimestamp(0);
            // dd(Carbon::createFromTimestamp(0)->toDateString());
        }
        if ($request->has('to') && $request->input('to') != '') {
            $date_to = Carbon::createFromFormat('m-d-Y', $request->input('to'));
            // dd($date_to);
        } else {
            $date_to = Carbon::now()->addYears(50);
            // dd(Carbon::now()->addYears(50)->toDateString());
        }
        
        if ( $firstname != "" || $lastname !="" || $neename != "" || $county != "" || $town !="" 
        || $date_from->toDateString() != Carbon::createFromTimestamp(0)->toDateString() || $date_to->toDateString() != Carbon::now()->addYears(50)->toDateString()){
            // dd('1');
              $estates = \DB::table('anothertable')->where("firstname","LIKE", "%" . $firstname . "%")
                ->where("lastname","LIKE", "%" . $lastname . "%")->where("neename","LIKE", "%" . $neename . "%")
                ->where("county","LIKE", "%" . $county . "%")->where("town","LIKE", "%" . $town . "%")
                ->whereBetween("published", [$date_from, $date_to]);
            // dd($estates->get());
                $estatesdatas = $estates->get();

            if(count($estatesdatas) > 0){
                $items = $estates->paginate(20)->appends(Input::except('page'));
                // dd($items);
                return view('landing',[
                    'estates' => $items
                ]);
            } else {
                $estates = [];
                $data['estates'] = $estates;
                return view("landing", $data);
            }

        }  else {
                // dd('3');
                $estates = \DB::table('anothertable');
                $items = $estates->paginate(20)->appends(Input::except('page'));
                return view('landing',[
                    'estates' => $items
                ]);
                // return view("landing", compact('estates'));
        }
        

    }

    public function replace(){

        $query = DB::table('anothertable')->select('published');
        //DB::table('noticeslist')->where('id', '>', 1000)->delete();

        $getpublished = $query->get();
        $i = 17;// start id will be replaced
        foreach($getpublished as $getpublish){
            
            DB::table('anothertable')->where('id', $i)->update(['published' => substr_replace($getpublish->published, '20', 6, 0)]);
            $i = $i + 1;

        }
    }

}
